package com.example.sample;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Canvas;
import android.hardware.Camera;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ListView;



@SuppressLint("SimpleDateFormat") public class SampleLoc extends Activity implements LocationListener {
	
	//GPS��臒l�ݒ�
	public static final int GPS_Range = 1;
	public static final int GPS_Time = 123;
	//GPS�擾�֌W
	private LocationManager lm;

	//�A���h���C�h�ԒʐM
	private final String TAG = getClass().getSimpleName();
	private Bt mBt;
	private final Drawer mDrawer = new Drawer();
	private ArrayAdapter<String> mCandidateServers;
	private ArrayAdapter<String> mServers;
	private View mView;
	private final Handler mHandler = new Handler();
	
	
	
	
	// �J�����C���X�^���X
    private Camera mCam = null;
    // �J�����v���r���[�N���X
    private CameraPreview mCamPreview = null;
    // �J�n�{�^����2�x�����֎~�p�t���O
    private boolean mIsTake = false;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //BLUETOOTH SET UP
        mCandidateServers = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		mServers = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		mView = new View(this) {
			@Override
			protected void onDraw(Canvas canvas) {
				if (mBt.isConnected()) {
					mDrawer.paint(canvas, mBt.getBoard().board);
				}
			}
		};

		mView.setOnTouchListener(new View.OnTouchListener() {
			@SuppressLint("ClickableViewAccessibility") @Override
			public boolean onTouch(View v, MotionEvent event) {
				int action = event.getAction();
				boolean result = false;
				if (MotionEvent.ACTION_DOWN == action && mBt.isConnected()) {
					result = true;
					int x = mDrawer.getX(event);
					int y = mDrawer.getY(event);
					Log.d(TAG, "onTouchEvent: x=" + event.getX() + "(" + x + ") y=" + event.getY() + "(" + y + ")");
					String message = mBt.getBoard().put(x, y);
					if (message != null) {
						invalidate();
						mBt.sendMessage(message);
					}
				}
				return result;
			}
		});
		mBt = new Bt(this, mCandidateServers, mServers);

		
		setContentView(R.layout.activity_sample_loc);
        
        // ���P�[�V�����}�l�[�W���̃C���X�^���X���擾����
        lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
                   
        // �J�����C���X�^���X�̎擾
        try {
            mCam = Camera.open();
        } catch (Exception e) {
            // �G���[
            this.finish();
        }
        // FrameLayout �� CameraPreview �N���X��ݒ�
        FrameLayout preview = (FrameLayout)findViewById(R.id.cameraPreview);
        mCamPreview = new CameraPreview(this, mCam);
        preview.addView(mCamPreview);
        
        //UI�ݒ�
        Button btnStart = (Button)findViewById(R.id.btnStart);
        btnStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //���[�P�[�V�����擾�����̐ݒ�
                Criteria criteria = new Criteria();
                criteria.setAccuracy(Criteria.ACCURACY_COARSE);
                criteria.setPowerRequirement(Criteria.POWER_LOW);
                criteria.setSpeedRequired(false);
                criteria.setAltitudeRequired(false);
                criteria.setBearingRequired(false);
                criteria.setCostAllowed(false);
                // �ʒu���̍X�V���󂯎��悤�ɐݒ�
                lm.requestLocationUpdates(
                		LocationManager.GPS_PROVIDER, // �v���o�C�_
                GPS_Time, // �ʒm�̂��߂̍ŏ����ԊԊu
                GPS_Range, // �ʒm�̂��߂̍ŏ������Ԋu
                new LocationListener(){// �ʒu��񃊃X�i�[,this�̓o�O������http://stackoverflow.com/questions/17119968/android-locationmanager-requestlocationupdates-doesnt-work
                	@Override
                	public void onStatusChanged(String provider, int status, Bundle extras) {
                        if (!mIsTake) {
                        	// �B�e����2�x�����֎~�p�t���O
                        	mIsTake = true;
                        	// �摜�擾
                        	mCam.takePicture(null, null, mPicJpgListener);
                        }
                	}
            	    @Override
            	    public void onProviderEnabled(String provider) {
                        if (!mIsTake) {
                        	// �B�e����2�x�����֎~�p�t���O
                        	mIsTake = true;
                        	// �摜�擾
                        	mCam.takePicture(null, null, mPicJpgListener);
                        }
            	    }
            	    @Override
            	    public void onProviderDisabled(String provider) {
                        if (!mIsTake) {
                        	// �B�e����2�x�����֎~�p�t���O
                        	mIsTake = true;
                        	// �摜�擾
                        	mCam.takePicture(null, null, mPicJpgListener);
                        }
            	    }
            	    @Override
            	    public void onLocationChanged(final Location location) {
                        if (!mIsTake) {
                        	// �B�e����2�x�����֎~�p�t���O
                        	mIsTake = true;
                        	// �摜�擾
                        	mCam.takePicture(null, null, mPicJpgListener);
                        }
            	    }
                }); 
            }
        });
        
        Button btnStop = (Button)findViewById(R.id.btnStop);
        btnStop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // �����ɏ������L�q
            	onStop();
            }
        });
    }


    @Override
	protected void onResume() {
		super.onResume();
		mBt.turnOn();
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        //lm.removeUpdates(pi);
        mBt.cancel();
        lm.removeUpdates(this);
        // �J�����j���C���X�^���X�����
        if (mCam != null) {
            mCam.release();
            mCam = null;
        }
    }
    public void onStop() {
    	super.onStop();
    	 
    	// �ʒu���̍X�V���~�߂�
    	lm.removeUpdates(this);
    	 
    }

    
    
    
    //�摜�֌W�̏���
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.sample_loc, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	int itemId = item.getItemId();
		if (itemId == R.id.menu_discoverable) {
			mBt.startDiscoverable();
		} else if (itemId == R.id.menu_start_server) {
			mBt.startServer();
		} else if (itemId == R.id.menu_search_server) {
			mCandidateServers.clear();
			ListView lv = new ListView(this);
			lv.setAdapter(mCandidateServers);
			lv.setScrollingCacheEnabled(false);
			final AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle(R.string.title_dialog)
			.setPositiveButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					mBt.cancelDiscovery();
				}
			})
			.setView(lv)
			.create();
			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> items, View view, int position, long id) {
					dialog.dismiss();
					String address = mCandidateServers.getItem(position);
					if (mServers.getPosition(address) == -1) {
						mServers.add(address);
					}
					mBt.cancelDiscovery();
				}
			});
			dialog.show();
			mBt.searchServer();
		} else if (itemId == R.id.menu_connect) {
			ListView lv = new ListView(this);
			final AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle(R.string.title_dialog)
			.setPositiveButton(android.R.string.cancel, null)
			.setView(lv)
			.create();
			lv.setAdapter(mServers);
			lv.setScrollingCacheEnabled(false);
			lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> items, View view, int position, long id) {
					dialog.dismiss();
					String address = mServers.getItem(position);
					mBt.connect(address);
				}
			});
			dialog.show();
		}
		//return true;
    	
    	
    	
    	// Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        if (itemId == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    /**
     * JPEG �f�[�^�����������̃R�[���o�b�N
     */
    private Camera.PictureCallback mPicJpgListener = new Camera.PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            if (data == null) {
                return;
            }

            String saveDir = Environment.getExternalStorageDirectory().getPath() + "/test";

            // SD �J�[�h�t�H���_���擾
            File file = new File(saveDir);

            // �t�H���_�쐬
            if (!file.exists()) {
                if (!file.mkdir()) {
                    Log.e("Debug", "Make Dir Error");
                }
            }

            // �摜�ۑ��p�X
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String imgPath = saveDir + "/" + sf.format(cal.getTime()) + ".jpg";

            // �t�@�C���ۑ�
            FileOutputStream fos;
            try {
                fos = new FileOutputStream(imgPath, true);
                fos.write(data);
                fos.close();

                // �A���h���C�h�̃f�[�^�x�[�X�֓o�^
                // (�o�^���Ȃ��ƃM�������[�Ȃǂɂ����ɔ��f����Ȃ�����)
                registAndroidDB(imgPath);

            } catch (Exception e) {
                Log.e("Debug", e.getMessage());
            }

            fos = null;

            // takePicture ����ƃv���r���[����~����̂ŁA�ēx�v���r���[�X�^�[�g
            mCam.startPreview();

            mIsTake = false;
        }
    };

    /**
     * �A���h���C�h�̃f�[�^�x�[�X�։摜�̃p�X��o�^
     * @param path �o�^����p�X
     */
    private void registAndroidDB(String path) {
        // �A���h���C�h�̃f�[�^�x�[�X�֓o�^
        // (�o�^���Ȃ��ƃM�������[�Ȃǂɂ����ɔ��f����Ȃ�����)
        ContentValues values = new ContentValues();
        ContentResolver contentResolver = SampleLoc.this.getContentResolver();
        values.put(Images.Media.MIME_TYPE, "image/jpeg");
        values.put("_data", path);
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    }
    
    

	
  //GPS�֌W�̏���
    public void onLocationChanged(Location location) {
    	// ��Ƃ��ă��x���Ɏ擾�����ʒu��\��
    	//TextView latitudeLabel = new TextView(null);
    	//TextView longitudeLabel = new TextView(null);
		//latitudeLabel.setText(Double.toString(location.getLatitude()));
    	//longitudeLabel.setText(Double.toString(location.getLongitude()));
    	 
    }
    	 
    public void onProviderEnabled(String provider) {
     
    }
    	 
    public void onProviderDisabled(String provider) {
     
    }
    	 
    public void onStatusChanged(String provider, int status, Bundle extras) {
    	 
    }    
    
    
  //Bluetooth
    @Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		mBt.onActivityResult(requestCode, resultCode, data);
	}


	public void invalidate() {
		// TODO Auto-generated method stub
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				mView.invalidate();
			}
		});
	}

    
}



