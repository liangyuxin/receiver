package com.example.sender;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

  private ToneGenerator toneGenerator = new ToneGenerator(
  AudioManager.STREAM_SYSTEM, ToneGenerator.MAX_VOLUME);
  private StringBuffer cbuf = new StringBuffer(128);
  int n;
  private DatagramSocket ds;
  private DatagramSocket ds2;
  private DatagramPacket dp;
  private DatagramPacket dp2;
  private String IP_remote;
  private String IP_remote2;
  private int port_remote;
  //GPS��臒l�ݒ�
  public static final int GPS_Range = 1;
  public static final int GPS_Time = 1;
  //GPS�擾�֌W
  private LocationManager lm;



  @Override  
  public void onCreate(Bundle savedInstanceState) {   
    super.onCreate(savedInstanceState);
    lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
  	//���[�P�[�V�����擾�����̐ݒ�
    Criteria criteria = new Criteria();
    criteria.setAccuracy(Criteria.ACCURACY_COARSE);
    criteria.setPowerRequirement(Criteria.POWER_LOW);
    criteria.setSpeedRequired(false);
    criteria.setAltitudeRequired(false);
    criteria.setBearingRequired(false);
    criteria.setCostAllowed(false);

    
    LinearLayout linearLayout = new LinearLayout(this);
    linearLayout.setOrientation(LinearLayout.VERTICAL);
    final Button button1 = new Button(this);
    final Button button3 = new Button(this);
    Button button2 = new Button(this);
    final TextView tv = new TextView(this);
    final TextView tv2 = new TextView(this);
    tv.setText("�J�E���^");
    button1.setText("Generate Trigger");
    button3.setText("Activate GPS");
    button2.setText("Reset");

      
      
    //���C�A�E�g
    linearLayout.addView(button1, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(button3, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(button2, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(tv, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    linearLayout.addView(tv2, new LinearLayout.LayoutParams(
    LinearLayout.LayoutParams.WRAP_CONTENT, 
    LinearLayout.LayoutParams.WRAP_CONTENT));
    setContentView(linearLayout);
  
    IP_remote2 = "172.20.10.11"; //IP�A�h���X
    IP_remote = "172.20.10.9"; //IP�A�h���X
    port_remote = 1234;       //�|�[�g�ԍ�     

      // Button1 ���N���b�N���ꂽ���ɌĂяo�����R�[���o�b�N��o�^   
      button1.setOnClickListener(new View.OnClickListener() {   
        public void onClick(View v) {   
          n++;
          // ����������
          cbuf.append(n);
          tv.setText(cbuf.toString());  // tv �ɂ� final ���K�v  
          cbuf.delete(0, 99);
          toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP);

          // UDP�@���M                     
          new Thread(new Runnable() {
            public void run() {                 
              try{      
            	InetAddress host = InetAddress.getByName(IP_remote);
            	InetAddress host2 = InetAddress.getByName(IP_remote2);
            	String message = "1";  // ���M���b�Z�[�W     
                        ds = new DatagramSocket();  //DatagramSocket �쐬
                        ds2 = new DatagramSocket();  //DatagramSocket �쐬
                        byte[] data = message.getBytes();       
                        dp = new DatagramPacket(data, data.length, host, port_remote);  //DatagramPacket �쐬 
                        dp2 = new DatagramPacket(data, data.length, host2, port_remote);  //DatagramPacket �쐬 
                        ds2.send(dp2);
                        ds.send(dp);
                        tv2.setText("���M�������܂���");
                        tv2.setText("���M�������܂���");
                     }catch(Exception e){
                        System.err.println("Exception : " + e);
                        //tv2.setText("���M���s���܂���" + e);
                     }          
            }
          }).start();
        } 
      });
      // Button3 ���N���b�N���ꂽ���ɌĂяo�����R�[���o�b�N��o�^   
      button1.setOnClickListener(new View.OnClickListener() {   
        public void onClick(View v) {
        	// �ʒu���̍X�V���󂯎��悤�ɐݒ�
            lm.requestLocationUpdates(
            		LocationManager.GPS_PROVIDER, // �v���o�C�_
            GPS_Time, // �ʒm�̂��߂̍ŏ����ԊԊu
            GPS_Range, // �ʒm�̂��߂̍ŏ������Ԋu
            new LocationListener(){// �ʒu��񃊃X�i�[,this�̓o�O������http://stackoverflow.com/questions/17119968/android-locationmanager-requestlocationupdates-doesnt-work
            	@Override
            	public void onStatusChanged(String provider, int status, Bundle extras) {
                }
        	    @Override
        	    public void onProviderEnabled(String provider) {
        	    }
        	    @Override
        	    public void onProviderDisabled(String provider) {
        	    }
        	    @Override
        	    public void onLocationChanged(final Location location) {
                    	button1 .performClick();
            	}
            });
        } 
      });
      
      


      
      
      
      
      // �J�E���^�̌��� 
      button2.setOnClickListener(new View.OnClickListener() {   
        public void onClick(View v) {   
          n--;
          cbuf.append(n);
          tv.setText(cbuf.toString());  
          cbuf.delete(0, 99);
          toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP);
        } 
      });   

    n=0;        // �J�E���g�l�̏����l
    try{        
      InetAddress host = InetAddress.getByName(IP_remote);      // IP�A�h���X
      String message = "send by Android";  // ���M���b�Z�[�W     
      ds = new DatagramSocket();  //DatagramSocket �쐬
      byte[] data = message.getBytes(); 
      dp = new DatagramPacket(data, data.length, host, port_remote);  //DatagramPacket �쐬                               
      tv2.setText("���������������܂���");
    }catch(Exception e){
      System.err.println("Exception : " + e);
      tv2.setText("�������Ɏ��s���܂���");
    }
  // end OnCreat()   
  }
	protected void onResume() {
		super.onResume();
	}
    
    @Override
    protected void onPause() {
        super.onPause();
        //lm.removeUpdates(this);
        // �J�����j���C���X�^���X�����
    }
    public void onStop() {
    	super.onStop();    	 
    	// �ʒu���̍X�V���~�߂�
    	//lm.removeUpdates(this);
    }
}















        
    

    
    
  