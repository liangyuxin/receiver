package com.example.sample;

import java.util.StringTokenizer;

import android.util.Log;

public class Board {
	private final String TAG = getClass().getSimpleName();
	String conDition = "0,0";
	static final int COLOR_BLANK = 0;
	static final int COLOR_BLACK = 1;
	static final int COLOR_WHITE = 2;
	private final int color;
	private boolean myTurn;

	public Board(int color) {
		this.color = color;
		myTurn = color == COLOR_BLACK;
	}
	
	public String put(int x, int y) {
		conDition =  x + "," + y;
		return conDition;
	}

	public String check() {
		return conDition;
	}
	
	public void receiveMessage(String message) {
		Log.d(TAG, "receiveMessage:" + message);
		StringTokenizer st = new StringTokenizer(message, ",");
		int x = Integer.parseInt(st.nextToken());
		int y = Integer.parseInt(st.nextToken());
		put(x, y);
	}
}
